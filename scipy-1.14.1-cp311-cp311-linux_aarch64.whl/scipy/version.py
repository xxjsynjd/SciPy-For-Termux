# THIS FILE IS GENERATED DURING THE SCIPY BUILD
# See tools/version_utils.py for details

short_version = '1.14.1'
version = '1.14.1'
full_version = '1.14.1'
git_revision = '9a76330'
commit_count = '0'
release = True

if not release:
    version = full_version
