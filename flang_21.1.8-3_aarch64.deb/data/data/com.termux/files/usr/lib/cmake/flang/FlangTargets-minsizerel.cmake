#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "FortranEvaluate" for configuration "MinSizeRel"
set_property(TARGET FortranEvaluate APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FortranEvaluate PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFortranEvaluate.a"
  )

list(APPEND _cmake_import_check_targets FortranEvaluate )
list(APPEND _cmake_import_check_files_for_FortranEvaluate "${_IMPORT_PREFIX}/lib/libFortranEvaluate.a" )

# Import target "FortranDecimal" for configuration "MinSizeRel"
set_property(TARGET FortranDecimal APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FortranDecimal PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFortranDecimal.a"
  )

list(APPEND _cmake_import_check_targets FortranDecimal )
list(APPEND _cmake_import_check_files_for_FortranDecimal "${_IMPORT_PREFIX}/lib/libFortranDecimal.a" )

# Import target "FortranLower" for configuration "MinSizeRel"
set_property(TARGET FortranLower APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FortranLower PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFortranLower.a"
  )

list(APPEND _cmake_import_check_targets FortranLower )
list(APPEND _cmake_import_check_files_for_FortranLower "${_IMPORT_PREFIX}/lib/libFortranLower.a" )

# Import target "FortranParser" for configuration "MinSizeRel"
set_property(TARGET FortranParser APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FortranParser PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFortranParser.a"
  )

list(APPEND _cmake_import_check_targets FortranParser )
list(APPEND _cmake_import_check_files_for_FortranParser "${_IMPORT_PREFIX}/lib/libFortranParser.a" )

# Import target "FortranSemantics" for configuration "MinSizeRel"
set_property(TARGET FortranSemantics APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FortranSemantics PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFortranSemantics.a"
  )

list(APPEND _cmake_import_check_targets FortranSemantics )
list(APPEND _cmake_import_check_files_for_FortranSemantics "${_IMPORT_PREFIX}/lib/libFortranSemantics.a" )

# Import target "FortranSupport" for configuration "MinSizeRel"
set_property(TARGET FortranSupport APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FortranSupport PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFortranSupport.a"
  )

list(APPEND _cmake_import_check_targets FortranSupport )
list(APPEND _cmake_import_check_files_for_FortranSupport "${_IMPORT_PREFIX}/lib/libFortranSupport.a" )

# Import target "flangFrontend" for configuration "MinSizeRel"
set_property(TARGET flangFrontend APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(flangFrontend PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libflangFrontend.a"
  )

list(APPEND _cmake_import_check_targets flangFrontend )
list(APPEND _cmake_import_check_files_for_flangFrontend "${_IMPORT_PREFIX}/lib/libflangFrontend.a" )

# Import target "flangFrontendTool" for configuration "MinSizeRel"
set_property(TARGET flangFrontendTool APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(flangFrontendTool PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libflangFrontendTool.a"
  )

list(APPEND _cmake_import_check_targets flangFrontendTool )
list(APPEND _cmake_import_check_files_for_flangFrontendTool "${_IMPORT_PREFIX}/lib/libflangFrontendTool.a" )

# Import target "FIRAnalysis" for configuration "MinSizeRel"
set_property(TARGET FIRAnalysis APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRAnalysis PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRAnalysis.a"
  )

list(APPEND _cmake_import_check_targets FIRAnalysis )
list(APPEND _cmake_import_check_files_for_FIRAnalysis "${_IMPORT_PREFIX}/lib/libFIRAnalysis.a" )

# Import target "FIRBuilder" for configuration "MinSizeRel"
set_property(TARGET FIRBuilder APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRBuilder PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRBuilder.a"
  )

list(APPEND _cmake_import_check_targets FIRBuilder )
list(APPEND _cmake_import_check_files_for_FIRBuilder "${_IMPORT_PREFIX}/lib/libFIRBuilder.a" )

# Import target "FIRCodeGen" for configuration "MinSizeRel"
set_property(TARGET FIRCodeGen APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRCodeGen PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRCodeGen.a"
  )

list(APPEND _cmake_import_check_targets FIRCodeGen )
list(APPEND _cmake_import_check_files_for_FIRCodeGen "${_IMPORT_PREFIX}/lib/libFIRCodeGen.a" )

# Import target "FIRDialectSupport" for configuration "MinSizeRel"
set_property(TARGET FIRDialectSupport APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRDialectSupport PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRDialectSupport.a"
  )

list(APPEND _cmake_import_check_targets FIRDialectSupport )
list(APPEND _cmake_import_check_files_for_FIRDialectSupport "${_IMPORT_PREFIX}/lib/libFIRDialectSupport.a" )

# Import target "CUFAttrs" for configuration "MinSizeRel"
set_property(TARGET CUFAttrs APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(CUFAttrs PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libCUFAttrs.a"
  )

list(APPEND _cmake_import_check_targets CUFAttrs )
list(APPEND _cmake_import_check_files_for_CUFAttrs "${_IMPORT_PREFIX}/lib/libCUFAttrs.a" )

# Import target "CUFDialect" for configuration "MinSizeRel"
set_property(TARGET CUFDialect APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(CUFDialect PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libCUFDialect.a"
  )

list(APPEND _cmake_import_check_targets CUFDialect )
list(APPEND _cmake_import_check_files_for_CUFDialect "${_IMPORT_PREFIX}/lib/libCUFDialect.a" )

# Import target "FIRCodeGenDialect" for configuration "MinSizeRel"
set_property(TARGET FIRCodeGenDialect APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRCodeGenDialect PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRCodeGenDialect.a"
  )

list(APPEND _cmake_import_check_targets FIRCodeGenDialect )
list(APPEND _cmake_import_check_files_for_FIRCodeGenDialect "${_IMPORT_PREFIX}/lib/libFIRCodeGenDialect.a" )

# Import target "FIRDialect" for configuration "MinSizeRel"
set_property(TARGET FIRDialect APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRDialect PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRDialect.a"
  )

list(APPEND _cmake_import_check_targets FIRDialect )
list(APPEND _cmake_import_check_files_for_FIRDialect "${_IMPORT_PREFIX}/lib/libFIRDialect.a" )

# Import target "HLFIRDialect" for configuration "MinSizeRel"
set_property(TARGET HLFIRDialect APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(HLFIRDialect PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libHLFIRDialect.a"
  )

list(APPEND _cmake_import_check_targets HLFIRDialect )
list(APPEND _cmake_import_check_files_for_HLFIRDialect "${_IMPORT_PREFIX}/lib/libHLFIRDialect.a" )

# Import target "HLFIRTransforms" for configuration "MinSizeRel"
set_property(TARGET HLFIRTransforms APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(HLFIRTransforms PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libHLFIRTransforms.a"
  )

list(APPEND _cmake_import_check_targets HLFIRTransforms )
list(APPEND _cmake_import_check_files_for_HLFIRTransforms "${_IMPORT_PREFIX}/lib/libHLFIRTransforms.a" )

# Import target "FIROpenACCSupport" for configuration "MinSizeRel"
set_property(TARGET FIROpenACCSupport APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIROpenACCSupport PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIROpenACCSupport.a"
  )

list(APPEND _cmake_import_check_targets FIROpenACCSupport )
list(APPEND _cmake_import_check_files_for_FIROpenACCSupport "${_IMPORT_PREFIX}/lib/libFIROpenACCSupport.a" )

# Import target "FlangOpenMPTransforms" for configuration "MinSizeRel"
set_property(TARGET FlangOpenMPTransforms APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FlangOpenMPTransforms PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFlangOpenMPTransforms.a"
  )

list(APPEND _cmake_import_check_targets FlangOpenMPTransforms )
list(APPEND _cmake_import_check_files_for_FlangOpenMPTransforms "${_IMPORT_PREFIX}/lib/libFlangOpenMPTransforms.a" )

# Import target "FIROpenMPSupport" for configuration "MinSizeRel"
set_property(TARGET FIROpenMPSupport APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIROpenMPSupport PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIROpenMPSupport.a"
  )

list(APPEND _cmake_import_check_targets FIROpenMPSupport )
list(APPEND _cmake_import_check_files_for_FIROpenMPSupport "${_IMPORT_PREFIX}/lib/libFIROpenMPSupport.a" )

# Import target "flangPasses" for configuration "MinSizeRel"
set_property(TARGET flangPasses APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(flangPasses PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libflangPasses.a"
  )

list(APPEND _cmake_import_check_targets flangPasses )
list(APPEND _cmake_import_check_files_for_flangPasses "${_IMPORT_PREFIX}/lib/libflangPasses.a" )

# Import target "FIRSupport" for configuration "MinSizeRel"
set_property(TARGET FIRSupport APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRSupport PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRSupport.a"
  )

list(APPEND _cmake_import_check_targets FIRSupport )
list(APPEND _cmake_import_check_files_for_FIRSupport "${_IMPORT_PREFIX}/lib/libFIRSupport.a" )

# Import target "FIRTransforms" for configuration "MinSizeRel"
set_property(TARGET FIRTransforms APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(FIRTransforms PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_MINSIZEREL "CXX"
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib/libFIRTransforms.a"
  )

list(APPEND _cmake_import_check_targets FIRTransforms )
list(APPEND _cmake_import_check_files_for_FIRTransforms "${_IMPORT_PREFIX}/lib/libFIRTransforms.a" )

# Import target "bbc" for configuration "MinSizeRel"
set_property(TARGET bbc APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bbc PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bbc"
  )

list(APPEND _cmake_import_check_targets bbc )
list(APPEND _cmake_import_check_files_for_bbc "${_IMPORT_PREFIX}/bin/bbc" )

# Import target "flang" for configuration "MinSizeRel"
set_property(TARGET flang APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(flang PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/flang-21"
  )

list(APPEND _cmake_import_check_targets flang )
list(APPEND _cmake_import_check_files_for_flang "${_IMPORT_PREFIX}/bin/flang-21" )

# Import target "tco" for configuration "MinSizeRel"
set_property(TARGET tco APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(tco PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/tco"
  )

list(APPEND _cmake_import_check_targets tco )
list(APPEND _cmake_import_check_files_for_tco "${_IMPORT_PREFIX}/bin/tco" )

# Import target "f18-parse-demo" for configuration "MinSizeRel"
set_property(TARGET f18-parse-demo APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(f18-parse-demo PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/f18-parse-demo"
  )

list(APPEND _cmake_import_check_targets f18-parse-demo )
list(APPEND _cmake_import_check_files_for_f18-parse-demo "${_IMPORT_PREFIX}/bin/f18-parse-demo" )

# Import target "fir-opt" for configuration "MinSizeRel"
set_property(TARGET fir-opt APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(fir-opt PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/fir-opt"
  )

list(APPEND _cmake_import_check_targets fir-opt )
list(APPEND _cmake_import_check_files_for_fir-opt "${_IMPORT_PREFIX}/bin/fir-opt" )

# Import target "fir-lsp-server" for configuration "MinSizeRel"
set_property(TARGET fir-lsp-server APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(fir-lsp-server PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/fir-lsp-server"
  )

list(APPEND _cmake_import_check_targets fir-lsp-server )
list(APPEND _cmake_import_check_files_for_fir-lsp-server "${_IMPORT_PREFIX}/bin/fir-lsp-server" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
